Release notes:

V-Beta0.1:
- Finished all essential build phases, returned results with static model object.

V-Beta0.2:
- Added input error handling feature (preventing illegal input from computing
with invalid values).

V-Beta0.3:
- Corrected and enhanced input error handling feature by adding data type
detector and value observers.
- Completed search result sorting feature.
- Fixed bugs:
  - Result's innerHTML appending instead of replacing.
  - Result inaccurate with cases.
