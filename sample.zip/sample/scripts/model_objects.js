class Student {
  constructor(age, gpa, satScore, desiredDegree, collegeType, price) {
    this.age = age;
    this.gpa = gpa;
    this.satScore = satScore;
    this.desiredDegree = desiredDegree.toLowerCase();
    this.collegeType = collegeType.toLowerCase();
    this.price = price;
  }

  get getAge() {
    return this.age;
  }

  get getGPA() {
    return this.gpa;
  }

  get getSATScore() {
    return this.satScore;
  }

  get getDesiredDegree() {
    return this.desiredDegree;
  }

  get getCollegeType() {
    return this.collegeType;
  }

  get getPrice() {
    return this.price;
  }
}

class College {
  constructor(name, averageGpa, averageSat, bestDegrees, collegeType, price) {
    this.name = name;
    this.averageGpa = averageGpa;
    this.averageSat = averageSat;
    this.bestDegrees = bestDegrees.map(function(value) {
      return value.toLowerCase();
    });
    this.collegeType = collegeType.toLowerCase();
    this.price = price;
  }

  getInfo() {
    return {
      name: this.name,
      averageGpa: this.averageGpa,
      averageSat: this.averageSat,
      bestDegrees: this.bestDegrees,
      collegeType: this.collegeType,
      price: this.price
    };
  }

  get getName() {
    return this.name;
  }

  get getAverageGpa() {
    return this.averageGpa;
  }

  get getAverageSat() {
    return this.averageSat;
  }

  get getBestDegrees() {
    return this.bestDegrees;
  }

  get getCollegeType() {
    return this.collegeType;
  }

  get getPrice() {
    return this.price;
  }
}
