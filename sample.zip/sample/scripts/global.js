var colleges = [
  new College("College A", 2.4, 980, ["Biology", "Theatre"], "Community", 3000),
  new College("College B", 3.0, 1190, ["Chemistry", "Law"], "Public", 20000),
  new College("College C", 3.8, 1480, ["Mathematics", "Computer Science"], "Private", 30000),
  new College("College D", 3.6, 1400, ["Psychology", "Philosophy"], "Private", 32500)
];
